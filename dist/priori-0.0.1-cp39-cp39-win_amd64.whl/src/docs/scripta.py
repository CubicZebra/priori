main = """
script body
"""
